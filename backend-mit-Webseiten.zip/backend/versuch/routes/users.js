var express = require('express');
var router = express.Router();

var ADRESSE;
var CHANGE = "0";

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/* GET users listing. */
router.get('/hallo', function(req, res, next) {
  res.send('selber hallo');
});

/* GET users listing. */
router.get('/dekan', function(req, res, next) {
  CHANGE = "1";
  ADRESSE = './webseiten/kompletteSeite/startbootstrap-small-business-gh-pages/dekan.html';
  res.send('ok: dekan');
});

/* GET users listing. */
router.get('/ssc', function(req, res, next) {
  CHANGE = "1";
  ADRESSE = './webseiten/kompletteSeite/startbootstrap-small-business-gh-pages/index.html'
  res.send('ok: ssc');
});

/* GET users listing. */
router.get('/zeitenBib', function(req, res, next) {
  CHANGE = "1";
  ADRESSE = './webseiten/kompletteSeite/startbootstrap-small-business-gh-pages/oeffnungszeiten.html'
  res.send('ok: zeitenBib');
});

/* GET users listing. */
router.get('/adresse', function(req, res, next) {
  CHANGE = "0";
  res.send(ADRESSE);
});

/* GET users listing. */
router.get('/change', function(req, res, next) {
  console.log(CHANGE);
  res.send(CHANGE+"");
});

/* GET users listing. */
router.get('/prof', function(req, res, next) {
  CHANGE = "1";
  ADRESSE = "prof.html";
  res.send(ADRESSE);
});



module.exports = router;
